package com.rgtour.app;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import android.util.Base64;

public class MainActivity extends Activity {
  private WebView web;
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    web = new WebView(this);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(true);
    web.getSettings().setAllowFileAccess(true);
    web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient());
    web.addJavascriptInterface(new NativeActions(), "RGTOURNative");
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }
  @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
  private byte[] decode(String data) { String clean=data.contains(",")?data.substring(data.indexOf(',')+1):data; return Base64.decode(clean, Base64.DEFAULT); }
  private class NativeActions {
    @JavascriptInterface public void shareImage(String base64, String filename) {
      runOnUiThread(() -> { try {
        File dir=new File(getCacheDir(),"shared"); if(!dir.exists())dir.mkdirs();
        File f=new File(dir, safeName(filename)); try(FileOutputStream out=new FileOutputStream(f)){out.write(decode(base64));}
        Uri uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".provider",f);
        Intent send=new Intent(Intent.ACTION_SEND); send.setType("image/png"); send.putExtra(Intent.EXTRA_STREAM,uri); send.putExtra(Intent.EXTRA_TEXT,"Comprovante de passagem RGTOUR"); send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(send,"Compartilhar comprovante RGTOUR"));
      } catch(Exception e){Toast.makeText(MainActivity.this,"Não foi possível compartilhar a imagem",Toast.LENGTH_LONG).show();} });
    }
    @JavascriptInterface public void saveImage(String base64, String filename) {
      runOnUiThread(() -> { try {
        byte[] bytes=decode(base64); String name=safeName(filename);
        ContentValues values=new ContentValues(); values.put(MediaStore.Images.Media.DISPLAY_NAME,name); values.put(MediaStore.Images.Media.MIME_TYPE,"image/png");
        if(Build.VERSION.SDK_INT>=29) values.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/RGTOUR");
        Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);
        if(uri==null)throw new Exception("Não foi possível criar arquivo");
        try(OutputStream out=getContentResolver().openOutputStream(uri)){ if(out==null)throw new Exception("Arquivo indisponível"); out.write(bytes); }
        Toast.makeText(MainActivity.this,"Imagem salva em Imagens/RGTOUR",Toast.LENGTH_LONG).show();
      } catch(Exception e){Toast.makeText(MainActivity.this,"Falha ao salvar imagem",Toast.LENGTH_LONG).show();} });
    }
    @JavascriptInterface public void printReceipt() {
      runOnUiThread(() -> { try { PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE); String job="RGTOUR-comprovante"; pm.print(job,web.createPrintDocumentAdapter(job),new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(new android.print.PrintAttributes.Resolution("rgtour","RGTOUR",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build()); } catch(Exception e){Toast.makeText(MainActivity.this,"Não foi possível abrir o PDF",Toast.LENGTH_LONG).show();} });
    }
  }
  private String safeName(String name){ if(name==null||name.trim().isEmpty())return "RGTOUR-comprovante.png"; return name.replaceAll("[^A-Za-z0-9._-]","_"); }
}
